package com.walletApplication.exception;

public class WalletException extends Exception {

	
	private static final long serialVersionUID = 6758171865158904755L;

	public WalletException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public WalletException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
