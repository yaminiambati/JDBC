package com.walletApplication;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.walletApplication.bean.Wallet;
import com.walletApplication.exception.WalletException;
import com.walletApplication.service.WalletService;
import com.walletApplication.service.WalletServiceImpl;
public class App 
{
	
	Scanner scan=new Scanner(System.in);
	WalletService WalletService=new WalletServiceImpl();
	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("resources//log4j.properties");
		String option=null;
		
		App a=new App();
		a.scan.useDelimiter("\n");
		while(true) {
			System.out.println("=====WALLET MANAGEMENT SYSTEM=====");
			System.out.println("1)Create Account\n2)Show Balanace\n3)Deposit\n4)WithDraw\n5)Fund Transfer\n6)Print Transactions\n7)Exit");
			System.out.println("Enter Your Choice From 1 to 7");
			option=a.scan.nextLine();
			switch(option)
			{
			case "1":
				a.createaccount();
				break;
			case "2":
				a.showbalance();
				break;
			case "3":
				a.deposit();
				break;
			case "4":
				a.withdraw();
				break;
			case "5":
				a.fundtransfer();
				break;
			case "6":
				a.printtransactions();
				break;
			case "7":
				System.exit(0);
				break;
				default:
					System.out.println("Enter Valid Choice Between 1 to 7");
			
			}
		}
        
    }
	public void createaccount() {
	Wallet W=new Wallet();
		System.out.println("Enter Customer Name:");
		W.setName(scan.nextLine());
		System.out.println("Enter Account Type:");
		W.setAccountType(scan.nextLine());
		System.out.println("Enter Phone Number:");
		W.setPhoneNo(scan.nextLine());
		System.out.println("Enter Your Address:");
		W.setAddress(scan.nextLine());
		System.out.println("Enter Your Adhaar Number:");
		W.setAdhaarNo(scan.nextLine());
		System.out.println("Enter Your Email Id:");
		W.setEmail(scan.nextLine());
		W.setBalance(1000.00);
		System.out.println("Enter Your Age:");
		W.setAge(scan.nextLine());
		System.out.println("Enter Your Pin:");
		W.setPin(scan.nextLine());
		
		try {
			boolean result=WalletService.validateWallet(W);
			if(result) {
			long ret= WalletService.createaccount(W);
			System.out.println("Account with Account Number "+ret+" Created succesfully");
			}
			
		} catch (WalletException e) { 
			System.err.println("an error occured "+e.getMessage());
		}
		}
		
	
	public void showbalance() {
		
		System.out.println("Enter Your Account Number");
		Long accountno=Long.parseLong(scan.nextLine());
		System.out.println("Enter your Pin");
		String pin=scan.nextLine();
		try {
			boolean result=	WalletService.validate(accountno,pin);
			if(result){
				double balance=WalletService.showbalance(accountno);
				System.out.println("accont balance is:" +balance);
			
			}
		}catch (WalletException e) {
			System.err.println("an error occured "+e.getMessage());
		}
		
		
		
	}
	public void deposit() {
		System.out.println("Enter Your Account Number");
		Long accountno=Long.parseLong(scan.nextLine());
		
		System.out.println("Enter Your Pin:");
		String pin=scan.nextLine();
		try {
			boolean result=WalletService.validate(accountno,pin);
			if(result)
			{
				System.out.println("Enter The Amount To Be Deposited:");
				double amount=Double.parseDouble(scan.nextLine());	
				double newbalance=WalletService.deposit(accountno,amount);
				System.out.println("an amount of " +amount+ "has been deposited to the account "+accountno);
				System.out.println("Account Balance: "+newbalance);
				
			}
		}catch (WalletException e) {
			System.err.println("an error occured "+e.getMessage());
		}
		
		
	}
	public void withdraw() {
		System.out.println("Enter Your Account Number");
		Long accountno=Long.parseLong(scan.nextLine());
		
		System.out.println("Enter Your Pin:");
		String pin=scan.nextLine();
		try {
			boolean result=WalletService.validate(accountno,pin);
			if(result)
			{
				System.out.println("Enter The Amount To Be Withdrawn:");
				double amount=Double.parseDouble(scan.nextLine());	
				double newbalance=WalletService.withdraw(accountno,amount);
				System.out.println("an amount of " +amount+ "has been withdrawn from the account "+accountno);
				System.out.println("Account Balance: "+newbalance);
				
			}
		}catch (WalletException e) {
			System.err.println("an error occured "+e.getMessage());
		}
		
		
	}
	public void fundtransfer() {
		System.out.println("enter Account Number to which you want to transfer the fund:");
		long accountno1=Long.parseLong(scan.nextLine());
		System.out.println("enter your account number:");
		long accountno2=Long.parseLong(scan.nextLine());
		System.out.println("enter your valid pin:");
		String pin=scan.nextLine();
		try {
			boolean result=WalletService.validate(accountno2,pin);
			if(result)
			{
				System.out.println("Enter The Amount To Be Funded:");
				double amount=Double.parseDouble(scan.nextLine());	
				double totalbal=WalletService.fundtransfer(accountno1,accountno2,amount);
				System.out.println("Account Balance: " +totalbal);
		
			}
		}catch (WalletException e) {
				System.err.println("an error occured "+e.getMessage());
			}
	}
	public void printtransactions() {
		
		System.out.println("Enter Your Account Number");
		Long accountno=Long.parseLong(scan.nextLine());
		
		System.out.println("Enter Your Pin:");
		String pin=scan.nextLine();
		try {
			boolean result=WalletService.validate(accountno,pin);
			if(result)
			{
				boolean t=WalletService.printtransaction(accountno);
			}
			else
			{
				System.err.println("enter valid details");
			}
		}catch (WalletException e) {
			System.err.println("an error occured "+e.getMessage());
		}
		
		
		
	}
    	
    }

