package com.walletApplication.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.walletApplication.DB.WalletDb;
import com.walletApplication.bean.Transfer;
import com.walletApplication.bean.Wallet;
import com.walletApplication.exception.WalletException;
import com.walletApplication.util.DBConnection;



public class WalletDaoImpl implements WalletDao {
	Wallet W=new Wallet();

static HashMap<Integer,Transfer> TransferMap=WalletDb.getTransferMap();
Transfer tran=new Transfer();
Logger logger=Logger.getRootLogger();
	int transid=0;
	public WalletDaoImpl(){
	PropertyConfigurator.configure("resources//log4j.properties");
	}
	//Wallet w=new Wallet();
	
	
	
	@SuppressWarnings("resource")
	@Override
	public long createaccount(Wallet w) throws WalletException {
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		Long accountno=123456789008L;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,w.getName());
			preparedStatement.setString(2,w.getAccountType());
			preparedStatement.setString(3,w.getPhoneNo());
			preparedStatement.setString(4,w.getAddress());
			preparedStatement.setString(5,w.getAdhaarNo());
			preparedStatement.setString(6,w.getEmail());
			preparedStatement.setDouble(7,w.getBalance());
			preparedStatement.setString(8,w.getAge());
			preparedStatement.setString(9,w.getPin());
			
					
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.ACCOUNTNO_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				accountno=(long) resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting employee details failed ");

			}
			else
			{
				logger.info("Employee details added successfully:");
				return (long)accountno;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	}
	@Override
	public boolean validate(long accountno, String pin) throws WalletException {
		
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.Validate_query);
			preparedStatement.setLong(1,accountno);
			preparedStatement.setString(2,pin);
			resultSet=preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				return true;
			}else
			{
				throw  new WalletException(" Invalid Account Number or Pin.Enter Correct Details ");
			}
		}catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	}
	
	

	@Override
	public double showbalance(long accountno) throws WalletException {
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.SHOWBALANCE_QUERY);
			preparedStatement.setLong(1,accountno);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				double balance= resultSet.getDouble("Balance");
				return balance;
			}else
			{
				throw new WalletException("Enter Correct Account Number");
			}
		
}catch(SQLException sqlException)
		{
	logger.error(sqlException.getMessage());
	sqlException.printStackTrace();
	throw new WalletException("Tehnical problem occured refer log");
}
finally
{
	try 
	{
		preparedStatement.close();
		connection.close();
	}
	catch (SQLException sqlException) 
	{
		logger.error(sqlException.getMessage());
		throw new WalletException("Error in closing db connection");	
	}
}
		
	}

	@SuppressWarnings("resource")
	@Override
	public double deposit(long accountno, double amount) throws WalletException {
		if(amount<0)
			throw new WalletException("The amount to be deposited cannot be less than 0");
		else
		{
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try{
			preparedStatement=connection.prepareStatement(QueryMapper.deposit_query1);
		
			
			preparedStatement.setDouble(1,amount);
			preparedStatement.setLong(2,accountno);	
			resultSet=preparedStatement.executeQuery();
			preparedStatement=connection.prepareStatement(QueryMapper.balance_query);
			preparedStatement.setLong(1,accountno);	
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				double balance= resultSet.getDouble("Balance");
				return balance;
			}else
			{
				throw new WalletException("Enter correct account number and pin");
			}
		
			
	}catch(SQLException sqlException)
		{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}
		}
	}
	@SuppressWarnings("resource")
	@Override
	public double withdraw(long accountno, double amount) throws WalletException {
		if(amount<0)
			throw new WalletException("withdrawing amount cannot be less than 0");
		else
		{
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.balance_query);
			preparedStatement.setDouble(1,accountno);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
			double balance1= resultSet.getDouble("Balance");
			if(balance1<amount)
					throw new WalletException("insufficient balance in your account");
			else
			{	
				preparedStatement=connection.prepareStatement(QueryMapper.withdraw_query1);
	
	
				preparedStatement.setDouble(1,amount);
				preparedStatement.setLong(2,accountno);	
				resultSet=preparedStatement.executeQuery();
				preparedStatement=connection.prepareStatement(QueryMapper.balance_query);
				preparedStatement.setDouble(1,accountno);
				resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					double balance= resultSet.getDouble("Balance");
					return balance;
				}else
					throw new WalletException("invalid details");
			}
			}else
				throw new WalletException("invalid details");
		}catch(SQLException sqlException)
		{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}
		}
	}

	@SuppressWarnings("resource")
	@Override
	public double fundtransfer(long accountno1, long accountno2, double amount) throws WalletException {
Connection connection = DBConnection.getInstance().getConnection();	
PreparedStatement preparedStatement=null;		
ResultSet resultSet = null;
		if(amount<=0)
			throw new WalletException("for fund to be transfered fund must be greater than 0");
		else{
		
		try {preparedStatement=connection.prepareStatement(QueryMapper.accountnoverification_query);
		preparedStatement.setLong(1,accountno1);
		resultSet=preparedStatement.executeQuery();
		if(resultSet.next())
		{
			
			preparedStatement=connection.prepareStatement(QueryMapper.balance_query);
			preparedStatement.setLong(1,accountno2);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
			double balance1= resultSet.getDouble("Balance");
			if(balance1<amount)
					throw new WalletException("Low balance for fundtranfer");
			
			else 
				{
				preparedStatement=connection.prepareStatement(QueryMapper.withdraw_query1);
				
				preparedStatement.setDouble(1,amount);
				preparedStatement.setLong(2,accountno2);	
				resultSet=preparedStatement.executeQuery();
				preparedStatement=connection.prepareStatement(QueryMapper.deposit_query1);
				preparedStatement.setDouble(1,amount);
				preparedStatement.setLong(2,accountno1);	
				resultSet=preparedStatement.executeQuery();
				
				preparedStatement=connection.prepareStatement(QueryMapper.balance_query);
				preparedStatement.setLong(1,accountno2);
				resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
				double balance2= resultSet.getDouble("Balance");
				return balance2;
				}else
					throw new WalletException("invalid account detailsdetails");
			}
			}else
				throw new WalletException("invalid details");
		}else
		{
			throw new WalletException("invalid details");
		}
		}
			catch(SQLException sqlException)
		{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}
		}
	}			
			
				
			


	@Override
	public boolean printtransaction(long accountno) throws WalletException {
		try {
			for(int k=1;k<=TransferMap.size();k++) {
				Transfer tran=TransferMap.get(k);
						if(tran.getAccountno()==accountno)
						{
							System.out.println(tran);;
						}
			}return false;
		}catch(Exception ex)
		{
			throw new  WalletException (ex.getMessage());
			
		}
		
	}

}
