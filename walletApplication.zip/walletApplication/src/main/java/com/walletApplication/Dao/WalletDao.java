package com.walletApplication.Dao;

import com.walletApplication.bean.Wallet;
import com.walletApplication.exception.WalletException;


public interface WalletDao {
	long createaccount(Wallet w)throws WalletException;

	boolean validate(long accountno, String pin)throws WalletException;

	double showbalance(long accountNo) throws WalletException;

	double deposit(long accountno, double amount) throws  WalletException;

	double withdraw(long accountno, double amount) throws  WalletException;

	double fundtransfer(long accountno1, long accountno2, double amount) throws  WalletException;

	boolean printtransaction(long accountno) throws  WalletException;
	
	
	
	
}
