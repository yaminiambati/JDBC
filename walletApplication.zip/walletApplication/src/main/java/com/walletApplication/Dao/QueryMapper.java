package com.walletApplication.Dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO wallet VALUES(AccountNo_sequence.NEXTVAL,?,?,?,?,?,?,?,?,?)";
	public static final String ACCOUNTNO_QUERY_SEQUENCE="SELECT AccountNo_sequence.CURRVAL FROM DUAL";
	public static final String SHOWBALANCE_QUERY="SELECT Balance from wallet WHERE AccountNO=?";
	public static final String Validate_query="select AccountNo,Pin from wallet where accountno=? AND pin=?";
    public static final String deposit_query1="update  wallet SET Balance=Balance+? where AccountNo=?";
    public static final String balance_query="select Balance from wallet where AccountNo=?";
    public static final String  withdraw_query1="update wallet SET Balance=Balance-? where AccountNo=?";
    public static final String accountnoverification_query="select AccountNo from wallet where AccountNo=?";
 
   
}
