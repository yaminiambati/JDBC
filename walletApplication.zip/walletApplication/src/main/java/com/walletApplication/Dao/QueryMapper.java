package com.walletApplication.Dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO wallet VALUES(AccountNo_sequence.NEXTVAL,?,?,?,?,?,?,?,?,?)";
	public static final String ACCOUNTNO_QUERY_SEQUENCE="SELECT AccountNo_sequence.CURRVAL FROM DUAL";
	public static final String SHOWBALANCE_QUERY="SELECT Balance from wallet WHERE AccountNO=?";
	public static final String Validate_query="select AccountNo,Pin from wallet where accountno=? AND pin=?";
    public static final String deposit_query1="update  wallet SET Balance=Balance+? where AccountNo=?";
    public static final String balance_query="select Balance from wallet where AccountNo=?";
    public static final String  withdraw_query1="update wallet SET Balance=Balance-? where AccountNo=?";
    public static final String accountnoverification_query="select AccountNo from wallet where AccountNo=?";
    public static final String transfer_query1="insert into transfer values(transid_sequence.NEXTVAL,?,?,?,?)";
    public static final String date_query="select sysdate from dual";
    public static final String transfer_query_sequence="select transid_sequence.CURRVAL from dual";
    public static final String transfer_query2="select * from transfer where accountno=?";
 
   
    
    /***********************************
     * 
     * create table wallet(
    		AccountNo number(12),
    		Name varchar2(30),	 
    		AccountType varchar2(20),
    		PhoneNo varchar2(10),
    		Address varchar2(30),
    		AdhaarNo varchar2(12),
    		Email varchar2(20),
    		Balance number(10),
    		Age varchar2(10),
    		Pin varchar(10));  

    		create sequence AccountNo_sequence;

    		create table transfer(transid number(5),transfertype varchar2(20),amount number(10),transDate date,accountno number(12));

    		select * from transfer;
    		create sequence transid_sequence;  
    		*****************************************/
}
